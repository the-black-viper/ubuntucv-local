.. cmake-module:: ../../Modules/CMakeDependentOption.cmake
